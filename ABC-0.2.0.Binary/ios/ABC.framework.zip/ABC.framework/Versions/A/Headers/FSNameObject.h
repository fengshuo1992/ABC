//
//  FSNameObject.h
//  Animation
//
//  Created by fengshuo on 2020/8/26.
//  Copyright © 2020 fengshuo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSNameObject : NSObject

- (void)fsNameObjcet;

@end

NS_ASSUME_NONNULL_END
