//
//  ABC.h
//  
//
//  Created by fengshuo on 2020/8/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABC : NSObject

///测试
- (void)test;

///谁在测试
- (void)testName:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
